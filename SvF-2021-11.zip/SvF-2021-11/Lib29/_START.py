# -*- coding: UTF-8 -*-
import sys
import platform
import os
prog_name = sys.argv[0]
path_SvF_Lib            = prog_name[: prog_name.rfind('/')]
path_SvF                = path_SvF_Lib.split('Lib')[0]
path_pyomo_everest_ssop  = path_SvF + "pyomo-everest/ssop"
path_Everest_python_api = path_SvF + "Everest/python-api"

sys.path.append( path_SvF_Lib )
sys.path.append( path_SvF )
#sys.path.append( path_Pyomo_Everest_pe )        #old
sys.path.append( path_pyomo_everest_ssop )
sys.path.append( path_Everest_python_api )

#print (path_SvF)
#print (path_SvF_Lib)

import COMMON as co
co.path_SvF   = path_SvF
co.tmpFileDir = path_SvF + 'TMP/'
co.token      = path_Everest_python_api +'/.token'
co.startDir  =  os.getcwd()

print ( co.startDir )
sys.path.append( co.startDir )

from ReadMng import *

while (1) :
    Task = ReadMng ( )
    if co.Preproc :

        print ('\n\nCWD', os.getcwd(),  'RUN   StartModel.py *****************' )
        sys.path.append( os.getcwd() )
        exec(open("StartModel.py").read())
        with open(co.resF, 'a') as f:  # RES filewrite
            f.write('addStrToRes: ' + co.addStrToRes)
    if co.EofTask:
        print('\n\n\n *********  END OF TASK! **************')
        co.Preproc = True
        co.SModelFile = None
        co.ModelFile = None
        co.resF = ''
        co.OptStep = '0.01'
        co.optEstim = float_info.max
        co.curentTabl = None
        co.useNaN = False
    else :  break

print ('END OF FILE!');
exit(0)


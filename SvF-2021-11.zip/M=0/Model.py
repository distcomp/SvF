
from __future__ import division
from  numpy import *

from Lego import *
from pyomo.environ import *

def createGr ( Task, Penal ) :
    Funs = Task.Funs
    Gr = ConcreteModel()
    Task.Gr = Gr
    if com.CV_NoR > 0:
        Gr.mu = Param ( range(com.CV_NoR), mutable=True, initialize = 1 )

    x = Task.Grids[0]

    t = Task.Grids[1]

    sT = Task.Grids[2]
 											# T(x,t)>=0
    T = Funs[0];  T__f = T
    T__i = Var ( Funs[0].A[0].NodS,Funs[0].A[1].NodS,domain=Reals, bounds=(0,None), initialize = 1 )
    T.var = T__i ; Gr.T =  T__i
    T.InitByData()
    def fT(x,t) : return T.F([x,t])
 											# φ(x)>=0
    φ = Funs[1];  φ__f = φ
    φ__i = Var ( Funs[1].A[0].NodS,domain=Reals, bounds=(0,None), initialize = 1 )
    φ.var = φ__i ; Gr.φ =  φ__i
    φ.InitByData()
    def fφ(x) : return φ__f.F([x])
 											# l(t)>=0
    l = Funs[2];  l__f = l
    l__i = Var ( Funs[2].A[0].NodS,domain=Reals, bounds=(0,None), initialize = 1 )
    l.var = l__i ; Gr.l =  l__i
    l.InitByData()
    def fl(t) : return l__f.F([t])
 											# r(t)>=0
    r = Funs[3];  r__f = r
    r__i = Var ( Funs[3].A[0].NodS,domain=Reals, bounds=(0,None), initialize = 1 )
    r.var = r__i ; Gr.r =  r__i
    r.InitByData()
    def fr(t) : return r__f.F([t])
 											# K(sT)>=0;<=10;PolyPow=7
    K = Funs[4];  K__f = K
    K__i = Var ( range (8), initialize = 0 )
    K.var = K__i ; Gr.K =  K__i
    def fK(sT) : return K__f.F([sT])
    K__i[0].value = 1
 											# K(sT)>=0
    def EQ0 (Gr,i__sT) :
        return (
          fK(i__sT)>=0
        )
    Gr.conEQ0 = Constraint(sT.FlNodS,rule=EQ0 )
 											# K(sT)<=10
    def EQ1 (Gr,i__sT) :
        return (
          fK(i__sT)<=10
        )
    Gr.conEQ1 = Constraint(sT.FlNodS,rule=EQ1 )
 											# \frac{d}{d t}(T)=K(T)*\frac{d^2}{d x^2}(T)+\frac{d}{d T}(K(T))*(\frac{d}{d x}(T))**2
    def EQ2 (Gr,i__x,i__t) :
        return (
          ((fT(i__x,i__t)-fT(i__x,(i__t-t.step)))/t.step)==fK(fT(i__x,i__t))*((fT((i__x+x.step),i__t)+fT((i__x-x.step),i__t)-2*fT(i__x,i__t))/x.step**2)+(K__f.dF_dX(fT(i__x,i__t)))*(((fT(i__x,i__t)-fT((i__x-x.step),i__t))/x.step))**2
        )
    Gr.conEQ2 = Constraint(x.mFlNodSm,t.mFlNodS,rule=EQ2 )
 											# T(0,t)=l(t)
    def EQ3 (Gr,i__t) :
        return (
          fT(0,i__t)==fl(i__t)
        )
    Gr.conEQ3 = Constraint(t.FlNodS,rule=EQ3 )
 											# T(2,t)=r(t)
    def EQ4 (Gr,i__t) :
        return (
          fT(2,i__t)==fr(i__t)
        )
    Gr.conEQ4 = Constraint(t.FlNodS,rule=EQ4 )
 											# T(x,0)=φ(x)
    def EQ5 (Gr,i__x) :
        return (
          fT(i__x,0)==fφ(i__x)
        )
    Gr.conEQ5 = Constraint(x.FlNodS,rule=EQ5 )

    T.mu = Gr.mu; T.testSet = co.testSet; T.teachSet = co.teachSet;
 											# T.ComplSig2([Penal[0],Penal[1]])+T.MSD()
    def obj_expression(Gr):  
        return (
             T.ComplSig2([Penal[0],Penal[1]])+T.MSD()
        )  
    Gr.OBJ = Objective(rule=obj_expression)  

    return Gr

def print_res(Task, Penal, f__f):

    Gr = Task.Gr

    T = Task.Funs[0]

    l = Task.Funs[2]

    OBJ_ = Gr.OBJ ()
    print (  '    OBJ =', OBJ_ )
    f__f.write ( '\n    OBJ ='+ str(OBJ_)+'\n')
    tmp = (T.ComplSig2([Penal[0],Penal[1]]))
    stmp = str(tmp)
    print (      '    ',int(tmp/OBJ_*1000)/10,'\tT.ComplSig2([Penal[0],Penal[1]]) =', stmp )
    f__f.write ( '    '+str(int(tmp/OBJ_*1000)/10)+'\tT.ComplSig2([Penal[0],Penal[1]]) ='+ stmp+'\n')
    tmp = (T.MSD())
    stmp = str(tmp)
    print (      '    ',int(tmp/OBJ_*1000)/10,'\tT.MSD() =', stmp )
    f__f.write ( '    '+str(int(tmp/OBJ_*1000)/10)+'\tT.MSD() ='+ stmp+'\n')

    return
